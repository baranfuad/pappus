# From a Bent Cylinder to Centroid Curves: When Does Pappus Still Work?

*Baran Akter, 2026*

**[Read the paper (PDF)](pappus_paper.pdf)**

About 1700 years ago Pappus of Alexandria noticed that a doughnut has the same volume as the straight cylinder you get by cutting it open and straightening it. This project starts from that observation and follows it to a modern open question by H. Schmid (2025): if you slice a solid perpendicular to a *curved* curve, when do the slice areas add up exactly to the volume? This happens when every slice is balanced on the curve. Such curves are called **centroid curves**.

The paper is written for an undergraduate maths or physics reader. It has worked examples and a figure for each main idea.

## Results and their status

Every statement in the paper carries one of these labels: known, proved, computer-assisted proof, numerical, or conjecture.

| Statement | Status |
|---|---|
| Pappus's theorem, the bent cylinder, the extra π²r⁴ term in 4D (Weyl / Gauss–Bonnet) | Known |
| Slice areas add up to the volume along a centroid curve **even when the slices overlap** | Proved (short observation) |
| Ellipsoids: unique balanced plane at each point, all centroid curves, crossing curves and their exact smoothness, polynomial centroid curves | Proved |
| The √2-egg: if a = √2·b, **every parabola y = kx² through the centre is a centroid curve** | Proved |
| Global extension of centroid curves for centrally symmetric convex bodies | Proved, assuming hypothesis (U) |
| (U) fails on the axes of a cube | Proved |
| Box-corner centroid curves are hyperbolas; at least 7 balanced planes at a tetrahedron's centroid | Proved |
| Exactly 7 at the centroid; only 1 near a vertex | Numerical |
| Solid torus: a "fold" where balanced directions merge and disappear, at x = 0.905 | Computer-assisted proof (interval arithmetic) |
| Solid torus: traced centroid curves run into the fold and get stuck | Numerical |
| Generic centroid curves reach the centre along a direction of smallest central slice | Conjecture (proved for ellipsoids) |

"New" in the paper means "not found in our literature search". It has not yet been confirmed by an expert.

## Repository layout

```
main.tex, refs.bib     LaTeX source of the paper (pdfLaTeX + BibTeX)
pappus_paper.pdf       compiled paper
figures/               all figures used in the paper
code/                  every script behind every number and figure (see code/README.md)
  centroid_curves/     original research code
  referee/             independent re-check written from scratch, incl. the interval-arithmetic certificate
  paper_figs/          scripts that draw the figures made for the paper
```

## Build the paper

Upload the repository to Overleaf (New Project → Upload Project, using a zip of this folder), or build locally:

```
latexmk -pdf main.tex
```

## Run the code

```
pip install -r requirements.txt
cd code/centroid_curves
python3 sympy_checks.py        # symbolic checks (seconds)
python3 ellipsoid_check.py     # the sqrt(2)-egg, overlapping slices (~1 min)
cd ../referee
python3 check_ellipsoid.py     # independent 30-digit checks (seconds)
python3 torus_certify.py 4 "pts:0.905:-0.098:30,43.5,80,130"   # interval-arithmetic certificate
cd ../paper_figs
for f in *.py; do python3 $f; done   # regenerate the paper's figures
```

Run each script from inside its own folder. [`code/README.md`](code/README.md) and Appendix A of the paper explain in plain words what every script does, which result it checks, and how long it takes. The full torus certificate takes about an hour on 4 cores; its output is already saved in `code/referee/torus_certificates.txt`.

## How this work was done (AI disclosure)

This work was developed with AI assistance. The classical material (Sections 1–3) was first worked through with an AI assistant, then re-derived and checked. The research questions, proofs and computations (Sections 4–9) were also developed with AI assistance. An independent second pass re-derived every proof and re-did the key computations with new code (`code/referee/`). It found no mathematical errors and produced the interval-arithmetic certificate for the torus. All code is included so that every number can be reproduced.

An AI check catches algebra slips, missing hypotheses and numerical errors, but it is not a substitute for a mathematician reading the paper. The proofs in Sections 5–7 have not yet been reviewed by a human expert.

## Licence

The code is under the MIT License. The paper text and figures are under CC BY 4.0. See [LICENSE](LICENSE).
